# Opportunités foncières

Publier index.html et .nojekyll à la racine du dépôt.

Settings > Pages > Deploy from a branch > main > / (root).

ATTENTION : le HTML contient les données foncières. Publication soumise à autorisation. Ne pas ajouter les Excel, DXF ou GeoJSON au dépôt public.

Une connexion Internet est requise pour les fonds de carte. Les liens INJAZ restent soumis aux droits des utilisateurs.
